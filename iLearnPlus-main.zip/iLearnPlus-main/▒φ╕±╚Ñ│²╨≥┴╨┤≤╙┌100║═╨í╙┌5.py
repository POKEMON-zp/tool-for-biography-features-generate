import os
import csv
import pandas as pd
#输出结果无省略号
pd.set_option('display.max_rows', 50000)
pd.set_option('display.max_columns', 10000)
pd.set_option('display.width', 100000)
f1 = open(r"D:\Users\29549\Desktop\抗癌肽\1.csv", 'r')#读入名称+序列+位置
csvreader = csv.reader(f1)
final_list = list(csvreader)
ls = []
for k in final_list:
    k = str(k)
    if len(k)>=5 and len(k)<=96:
        ls.append(k)
df = pd.DataFrame(ls)
df.to_csv(r"D:\Users\29549\Desktop\抗癌肽\2.csv",index=False)

