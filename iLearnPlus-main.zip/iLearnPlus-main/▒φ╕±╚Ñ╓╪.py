import pandas as pd
df = pd.read_excel(r"D:\Users\29549\Desktop\1.xlsx")
df_unique = df.drop_duplicates()
df_unique.to_csv(r"D:\Users\29549\Desktop\正.csv", index=False)

