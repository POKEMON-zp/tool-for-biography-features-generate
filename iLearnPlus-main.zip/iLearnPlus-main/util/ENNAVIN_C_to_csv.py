import csv


def parse_fasta(file_path):
    with open(file_path, 'r') as file:
        sequences = []
        seq_name = ''
        seq = ''
        for line in file:
            line = line.strip()
            if line.startswith('>'):
                if seq_name:
                    sequences.append((seq_name, seq))
                seq_name = line[1:]
                seq = ''
            else:
                seq += line
        if seq_name:
            sequences.append((seq_name, seq))
    return sequences


def write_csv(sequences, output_path):
    with open(output_path, 'w', newline='') as csvfile:
        csvwriter = csv.writer(csvfile)
        csvwriter.writerow(['氨基酸', '序列', '标签'])
        for name, sequence in sequences:
            label = name[-1]  # Assuming the label is the last part of the name after '|'
            csvwriter.writerow([name[4:8], sequence, label])


def main():
    input_fasta = r"D:\Users\29549\Desktop\科研\ENNAVIA-C数据集\负.txt"  # Replace with your input FASTA file path
    output_csv = r"D:\Users\29549\Desktop\科研\ENNAVIA-C数据集\负.csv"  # Replace with your desired output CSV file path

    sequences = parse_fasta(input_fasta)
    write_csv(sequences, output_csv)


if __name__ == "__main__":
    main()
