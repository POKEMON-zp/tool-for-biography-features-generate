import os
import pandas as pd
import csv
# 定义文件夹路径
folder_path = r"D:\Users\29549\Desktop\acvp-257-1280\Negtive_1280_csv" # 替换为你的文件夹路径
output_file = r"D:\Users\29549\Desktop\acvp-257-1280\负.csv"  # 输出文件名

# 初始化一个空的DataFrame用于存储所有文件的平均值
all_averages = []

# 遍历文件夹中的所有CSV文件
for filename in os.listdir(folder_path):
    if filename.endswith('.csv'):
        file_path = os.path.join(folder_path, filename)

        # 读取CSV文件
        df = pd.read_csv(file_path)

        # 计算每列的平均值（跳过最后一列名字）
        averages = df.iloc[:, :-1].mean()
        averages = averages.tolist()
        # 将平均值添加到all_averages DataFrame中
        all_averages.append(averages)

# 打开文件并写入数据
with open(output_file, mode='w', newline='') as file:
    writer = csv.writer(file)
    writer.writerows(all_averages)

print(f"数据已保存到 {output_file}")