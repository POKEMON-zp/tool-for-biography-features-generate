#注意！注意！注意！ 此代码并没有转化第一行数据
import pandas as pd
df=pd.read_csv(r"D:\Users\29549\Desktop\抗癌肽\antiCancer补齐1.csv")
ans = 0
with open(r"D:\Users\29549\Desktop\抗癌肽\antiCancer补齐1.txt","w") as f:
    for index,row in df.iterrows():
#         ans+=1
#         if ans >= 353:
#             f.write(">" + row[0] + "|" + str(row[2]) + "|" + "testing" + "\n")
#             f.write(row[1] + "\n")
#         else :
#             f.write(">"+row[0]+"|"+str(row[2])+"|"+"training"+"\n")
#             f.write(row[1]+"\n")
        f.write(">" + row[0] + "|" + str(row[2]) + "|" + "training" + "\n")
        f.write(row[1] + "\n")