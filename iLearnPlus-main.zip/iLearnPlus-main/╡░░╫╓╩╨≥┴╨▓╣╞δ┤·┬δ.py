def read_fasta(file_path):
    sequences = {}
    with open(file_path, 'r') as file:
        header = ""
        for line in file:
            line = line.strip()
            if line.startswith(">"):
                header = line[1:]
                sequences[header] = ""
            else:
                sequences[header] += line
    return sequences


def pad_sequences(sequences):
    max_length = max(len(s) for s in sequences.values())
    padded_sequences = {}
    for header, sequence in sequences.items():
        padding = max_length - len(sequence)
        padded_sequences[header] = sequence + "X" * padding
    return padded_sequences


def write_fasta(padded_sequences, output_file_path):
    with open(output_file_path, 'w') as file:
        for header, sequence in padded_sequences.items():
            file.write(f">{header}\n{sequence}\n")


if __name__ == "__main__":
    input_file_path = r"D:\Python\pythonProject\python\抗菌肽\N.fasta"  # 替换为你的输入文件路径
    output_file_path = r"D:\Python\pythonProject\python\抗菌肽\N补齐.fasta"  # 替换为你的输出文件路径
    sequences = read_fasta(input_file_path)
    padded_sequences = pad_sequences(sequences)
    write_fasta(padded_sequences, output_file_path)
