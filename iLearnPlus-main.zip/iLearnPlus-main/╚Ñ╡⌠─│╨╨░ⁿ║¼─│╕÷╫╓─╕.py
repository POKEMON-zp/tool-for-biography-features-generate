# import pandas as pd

# # 读取CSV文件
# df = pd.read_csv(r"D:\Users\29549\Desktop\抗癌肽\antiCancer补齐.csv",encoding='ISO-8859-1')
#
# # 检查每一行是否包含字母'U'或'O'
# mask = ~df['xulie'].str.contains('U|O', na=False)

# # 应用掩码，保留不包含'U'和'O'的行
# filtered_df = df[mask]
#
# # 将过滤后的数据保存到新的CSV文件
# filtered_df.to_csv(r"D:\Users\29549\Desktop\抗癌肽\antiCancer补齐1.csv", index=False)


import pandas as pd

# 读取CSV文件
df = pd.read_csv(r"D:\Users\29549\Desktop\科研\A_P+E_C+F_A\正.csv", encoding='ISO-8859-1')

# 假设第二列的列名是 'column2'，请根据实际情况替换
mask = df['seq'].str.contains('U|O', na=False)

# 获取符合条件的第一列索引
indices = df.index[mask].tolist()

# 打印出这些索引
print(indices)