import pandas as pd

# 创建两个DataFrame
data1 = pd.read_csv(r"D:\Users\29549\Desktop\表\1.csv")
data2 = pd.read_csv(r"D:\Users\29549\Desktop\表\2.csv")
df1 = pd.DataFrame(data1)
df2 = pd.DataFrame(data2)

# 找出不同的行
diff_df1 = df1[~df1.isin(df2.to_dict(orient='list')).all(axis=1)]
diff_df2 = df2[~df2.isin(df1.to_dict(orient='list')).all(axis=1)]

# 打印结果
print("Rows in df1 not in df2:")
print(diff_df1)
print("\nRows in df2 not in df1:")
print(diff_df2)
